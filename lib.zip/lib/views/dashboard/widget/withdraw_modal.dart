import 'package:farm_loan_app/layout/custom_button.dart';
import 'package:farm_loan_app/layout/custom_form_input.dart';
import 'package:farm_loan_app/layout/custom_modal.dart';
import 'package:farm_loan_app/routes/custom_router.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class WithdrawModal extends StatefulWidget {
  const WithdrawModal({super.key});

  @override
  State<WithdrawModal> createState() => _WithdrawModalState();
}

class _WithdrawModalState extends State<WithdrawModal> {
  TextEditingController _controller = TextEditingController();
// TextEditingController _controller = TextEditingController();
// TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(24.sp),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Text(
                'Withdraw',
                style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w500),
              ),
            ],
          ),
          SizedBox(
            height: 30.h,
          ),
          CustomFormInput(
              label: 'Amount',
              controller: _controller,
              valText: '',
              callBack: (e) {}),
          SizedBox(
            height: 14.h,
          ),
          CustomFormInput(
              label: 'Account Number',
              controller: _controller,
              valText: '',
              callBack: (e) {}),
          SizedBox(
            height: 14.h,
          ),
          CustomFormInput(
              label: 'Account Name',
              controller: _controller,
              valText: '',
              callBack: (e) {}),
          SizedBox(
            height: 14.h,
          ),
          SizedBox(
            height: 10.h,
          ),
          CustomFormInput(
              label: 'Bank Name',
              controller: _controller,
              valText: '',
              callBack: (e) {}),
          SizedBox(
            height: 14.h,
          ),
          SizedBox(
            height: 10.h,
          ),
          CustomPrimaryButton(
              title: 'Continue',
              callBack: () {
                CustomRouters.routePop(context);
                successModalMinimal(
                    context, 'Withdraw success, your transaction is pending.');
              })
        ],
      ),
    );
  }
}
