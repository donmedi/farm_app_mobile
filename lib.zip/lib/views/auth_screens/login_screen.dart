import 'package:farm_loan_app/constant/color_const.dart';
import 'package:farm_loan_app/layout/custom_button.dart';
import 'package:farm_loan_app/layout/custom_form_input.dart';
import 'package:farm_loan_app/routes/app_routes.dart';
import 'package:farm_loan_app/routes/custom_router.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController _controller = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 40.h,
            ),
            Center(
              child: Image.asset(
                'images/logo.png',
                height: 250.h,
                width: 250.w,
              ),
            ),
            Text(
              'Discover an easy way to farm and make money',
              style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w600),
            ),
            SizedBox(
              height: 20,
            ),
            CustomFormInput(
                label: 'Email',
                controller: _controller,
                valText: '',
                callBack: () {}),
            SizedBox(
              height: 20,
            ),
            CustomFormInput(
                label: 'Password',
                controller: _controller,
                valText: '',
                callBack: () {}),
            SizedBox(
              height: 44.h,
            ),
            CustomPrimaryButton(
                title: 'Login',
                callBack: () {
                  CustomRouters.routePushWithName(context, AppRouter.dashboard);
                }),
            SizedBox(
              height: 34.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Forgot Password',
                  style:
                      TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
                ),
                InkWell(
                    onTap: () {
                      CustomRouters.routePushWithName(
                          context, AppRouter.register);
                    },
                    child: Text(
                      'Sign Up',
                      style: TextStyle(
                          color: ColorConst.mainPrimaryColor,
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w600),
                    )),
              ],
            )
          ],
        ),
      ),
    );
  }
}
