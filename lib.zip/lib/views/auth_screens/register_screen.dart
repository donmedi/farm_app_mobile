import 'package:farm_loan_app/constant/color_const.dart';
import 'package:farm_loan_app/layout/custom_button.dart';
import 'package:farm_loan_app/layout/custom_form_input.dart';
import 'package:farm_loan_app/routes/app_routes.dart';
import 'package:farm_loan_app/routes/custom_router.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  TextEditingController _controller = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 40.h,
            ),
            Text(
              'Login',
              style: TextStyle(fontSize: 24.sp, fontWeight: FontWeight.w600),
            ),
            SizedBox(
              height: 14.h,
            ),
            Text(
              'Discover an easy way to farm and make money',
              style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w500),
            ),
            SizedBox(
              height: 20,
            ),
            CustomFormInput(
                label: 'Firstname',
                controller: _controller,
                valText: '',
                callBack: () {}),
            SizedBox(
              height: 20,
            ),
            CustomFormInput(
                label: 'Last Name',
                controller: _controller,
                valText: '',
                callBack: () {}),
            SizedBox(
              height: 20,
            ),
            CustomFormInput(
                label: 'Email',
                controller: _controller,
                valText: '',
                callBack: () {}),
            SizedBox(
              height: 20,
            ),
            CustomFormInput(
                label: 'Password',
                controller: _controller,
                valText: '',
                callBack: () {}),
            SizedBox(
              height: 20,
            ),
            CustomFormInput(
                label: 'Confirm Password',
                controller: _controller,
                valText: '',
                callBack: () {}),
            SizedBox(
              height: 44.h,
            ),
            CustomPrimaryButton(title: 'Register', callBack: () {}),
            SizedBox(
              height: 34.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Already Have an account? ',
                  style:
                      TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w500),
                ),
                InkWell(
                  onTap: () {
                    CustomRouters.routePushWithName(context, AppRouter.login);
                  },
                  child: Text(
                    'Sign In',
                    style: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w700,
                        color: ColorConst.mainPrimaryColor),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
